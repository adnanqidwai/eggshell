#ifndef FUNCTION_H_
#define FUNCTION_H_

void init();
void dispupdate();
void getfirstword();
void remspace();
void checkdir();
void homedir(); 
void mainshell();
void xecho();
void xpwd();
void xcd();
void xls();
void xpinfo();
void xclear();
void processes();
void background();
void writehistory();
void readhistory();
void xdiscover();
void recursefunction();
void childkill(int);
void egg();

#endif