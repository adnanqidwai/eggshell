#ifndef SHELL_H_
#define SHELL_H_

#include "functions.h"
#include "variables.h"
#include<sys/stat.h>
#include<sys/types.h>
#include <sys/wait.h>
#include<stdio.h>
#include<fcntl.h>
#include <libgen.h>
#include<errno.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<stdlib.h>
#include<pwd.h>
#include<ctype.h>
#include<dirent.h>
#include<grp.h>
#include<time.h>
#include<signal.h>
#include<stddef.h>
#include<sys/sysinfo.h>


#endif